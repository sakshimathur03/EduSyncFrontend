import React, { useState, useEffect } from 'react';
import api from '../../services/api';

const getUserIdFromToken = () => {
  const token = localStorage.getItem('token');
  if (!token) return null;

  try {
    const payloadBase64 = token.split('.')[1];
    const decodedJson = atob(payloadBase64);
    const payload = JSON.parse(decodedJson);
    const claim = 'http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier';
    return payload[claim];
  } catch {
    return null;
  }
};

const TakeAssessment = ({ assessment, onComplete }) => {
  const [questions, setQuestions] = useState([]);
  const [answers, setAnswers] = useState({});

  useEffect(() => {
    if (!assessment) return;

    let parsedQuestions = [];
    try {
      parsedQuestions = typeof assessment.questions === 'string'
        ? JSON.parse(assessment.questions)
        : assessment.questions;
    } catch {
      parsedQuestions = [];
    }
    setQuestions(parsedQuestions || []);
  }, [assessment]);

  const handleChange = (qIndex, optionIndex) => {
    setAnswers(prev => ({ ...prev, [qIndex]: optionIndex }));
  };

  const handleSubmit = async () => {
    const userId = getUserIdFromToken();
    if (!userId) {
      alert('User not logged in.');
      return;
    }

    let score = 0;
    questions.forEach((q, i) => {
      const correctAnswer = isNaN(q.answer)
        ? q.options.indexOf(q.answer)
        : parseInt(q.answer);

      if (answers[i] === correctAnswer) score++;
    });

    const resultDto = {
      assessmentId: assessment.assessmentId,
      userId,
      score,
    };

    try {
      await api.post('/Results', resultDto);
      alert(`Assessment submitted! You scored ${score} / ${questions.length}`);
      onComplete();
    } catch (err) {
      console.error('Submission error:', err);
      alert('Submission failed.');
    }
  };

  if (!assessment) return <p style={{ marginTop: 20, textAlign: 'center' }}>No assessment selected.</p>;
  if (questions.length === 0) return <p style={{ marginTop: 20, textAlign: 'center' }}>Loading questions...</p>;

  return (
    <div style={{ maxWidth: 720, margin: '40px auto', fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif" }}>
      <h3 style={{ color: '#0d6efd', marginBottom: 30, textAlign: 'center' }}>{assessment.title}</h3>

      <form
        onSubmit={e => {
          e.preventDefault();
          handleSubmit();
        }}
      >
        {questions.map((q, i) => (
          <div
            key={i}
            style={{
              border: '1px solid #ddd',
              borderRadius: 14,
              padding: 24,
              marginBottom: 25,
              boxShadow: '0 3px 8px rgba(0,0,0,0.12)',
              backgroundColor: '#fff',
              transition: 'box-shadow 0.3s ease',
            }}
          >
            <h5 style={{ marginBottom: 20, color: '#212529', fontWeight: '600' }}>{q.question}</h5>

            {q.options.map((opt, j) => (
              <label
                key={j}
                style={{
                  display: 'block',
                  marginBottom: 12,
                  cursor: 'pointer',
                  fontSize: 16,
                  userSelect: 'none',
                  color: answers[i] === j ? '#0d6efd' : '#444',
                  fontWeight: answers[i] === j ? '700' : '400',
                  transition: 'color 0.25s ease',
                }}
              >
                <input
                  type="radio"
                  name={`question-${i}`}
                  checked={answers[i] === j}
                  onChange={() => handleChange(i, j)}
                  style={{ marginRight: 10, cursor: 'pointer' }}
                  required
                />
                {opt}
              </label>
            ))}
          </div>
        ))}

        <div style={{ textAlign: 'center' }}>
          <button
            type="submit"
            style={{
              backgroundColor: '#198754',
              color: 'white',
              padding: '14px 36px',
              border: 'none',
              borderRadius: 10,
              cursor: 'pointer',
              fontWeight: '700',
              fontSize: 18,
              boxShadow: '0 5px 15px rgba(25,135,84,0.5)',
              transition: 'background-color 0.3s ease',
            }}
            onMouseOver={e => (e.currentTarget.style.backgroundColor = '#157347')}
            onMouseOut={e => (e.currentTarget.style.backgroundColor = '#198754')}
          >
            Submit Assessment
          </button>
        </div>
      </form>
    </div>
  );
};

export default TakeAssessment;
