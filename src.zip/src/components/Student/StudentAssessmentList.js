import React, { useEffect, useState } from 'react';

const StudentAssessmentList = ({ onSelectAssessment }) => {
  const [courses, setCourses] = useState([]);
  const [selectedCourse, setSelectedCourse] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredCourses, setFilteredCourses] = useState([]);
  const [assessments, setAssessments] = useState([]);
  const [loadingCourses, setLoadingCourses] = useState(true);
  const [loadingAssessments, setLoadingAssessments] = useState(false);

  useEffect(() => {
    const fetchCourses = async () => {
      try {
        setLoadingCourses(true);
        const res = await fetch('/api/Courses');
        const data = await res.json();
        setCourses(data);
        setFilteredCourses(data);
      } catch {
        alert('Failed to load courses.');
      } finally {
        setLoadingCourses(false);
      }
    };
    fetchCourses();
  }, []);

  useEffect(() => {
    if (!selectedCourse) {
      setAssessments([]);
      return;
    }
    const fetchAssessments = async () => {
      try {
        setLoadingAssessments(true);
        const res = await fetch('/api/Assessments');
        const data = await res.json();
        const filtered = data.filter(a => a.courseId === selectedCourse.courseId);
        setAssessments(filtered);
      } catch {
        alert('Failed to load assessments.');
      } finally {
        setLoadingAssessments(false);
      }
    };
    fetchAssessments();
  }, [selectedCourse]);

  useEffect(() => {
    const lower = searchTerm.toLowerCase();
    setFilteredCourses(
      courses.filter(c => c.title.toLowerCase().includes(lower))
    );
  }, [searchTerm, courses]);

  return (
    <div style={{ maxWidth: 900, margin: '20px auto', fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif" }}>
      <h3 style={{ color: '#0d6efd', marginBottom: 20, textAlign: 'center' }}>Take an Assessment</h3>

      <input
        type="search"
        placeholder="Search courses..."
        value={searchTerm}
        onChange={e => setSearchTerm(e.target.value)}
        style={{
          width: '100%',
          padding: '10px 15px',
          fontSize: 16,
          marginBottom: 25,
          borderRadius: 6,
          border: '1px solid #ccc',
          boxSizing: 'border-box',
          outline: 'none',
          transition: 'border-color 0.3s ease',
        }}
        onFocus={e => (e.target.style.borderColor = '#0d6efd')}
        onBlur={e => (e.target.style.borderColor = '#ccc')}
      />

      {loadingCourses ? (
        <p style={{ textAlign: 'center' }}>Loading courses...</p>
      ) : filteredCourses.length === 0 ? (
        <p style={{ textAlign: 'center' }}>No courses found.</p>
      ) : (
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 16, justifyContent: 'center' }}>
          {filteredCourses.map(course => (
            <div
              key={course.courseId}
              onClick={() => setSelectedCourse(course)}
              role="button"
              tabIndex={0}
              onKeyDown={e => (e.key === 'Enter' || e.key === ' ') && setSelectedCourse(course)}
              style={{
                flex: '1 1 calc(30% - 16px)',
                minWidth: 220,
                border: selectedCourse?.courseId === course.courseId ? '3px solid #0d6efd' : '1px solid #ddd',
                borderRadius: 12,
                padding: 20,
                cursor: 'pointer',
                boxShadow: selectedCourse?.courseId === course.courseId ? '0 6px 15px rgba(13,110,253,0.3)' : '0 1px 4px rgba(0,0,0,0.1)',
                backgroundColor: selectedCourse?.courseId === course.courseId ? '#e7f1ff' : '#fff',
                userSelect: 'none',
                transition: 'all 0.3s ease',
                textAlign: 'center',
                fontWeight: '600',
                color: selectedCourse?.courseId === course.courseId ? '#0d6efd' : '#333',
              }}
            >
              {course.title}
            </div>
          ))}
        </div>
      )}

      {selectedCourse && (
        <div style={{ marginTop: 40 }}>
          <h5 style={{ color: '#198754', marginBottom: 20, textAlign: 'center' }}>
            Assessments for "{selectedCourse.title}"
          </h5>

          {loadingAssessments ? (
            <p style={{ textAlign: 'center' }}>Loading assessments...</p>
          ) : assessments.length === 0 ? (
            <p style={{ textAlign: 'center' }}>No assessments available for this course.</p>
          ) : (
            <ul style={{ listStyle: 'none', padding: 0, maxWidth: 700, margin: '0 auto' }}>
              {assessments.map(assessment => (
                <li
                  key={assessment.assessmentId}
                  style={{
                    padding: '16px 24px',
                    marginBottom: 16,
                    borderRadius: 12,
                    backgroundColor: '#f8f9fa',
                    boxShadow: '0 4px 12px rgba(0,0,0,0.08)',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    transition: 'background-color 0.3s ease',
                  }}
                >
                  <span style={{ fontWeight: 600, fontSize: 17, color: '#212529' }}>{assessment.title}</span>
                  <button
                    onClick={() => onSelectAssessment(assessment)}
                    style={{
                      backgroundColor: '#198754',
                      border: 'none',
                      color: 'white',
                      padding: '8px 20px',
                      borderRadius: 8,
                      cursor: 'pointer',
                      fontWeight: '600',
                      fontSize: 15,
                      boxShadow: '0 3px 7px rgba(25,135,84,0.6)',
                      transition: 'background-color 0.25s ease',
                    }}
                    onMouseOver={e => (e.currentTarget.style.backgroundColor = '#157347')}
                    onMouseOut={e => (e.currentTarget.style.backgroundColor = '#198754')}
                    aria-label={`Take assessment: ${assessment.title}`}
                  >
                    Take
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
};

export default StudentAssessmentList;
