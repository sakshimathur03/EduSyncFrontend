import React, { useState } from 'react';
import StudentAssessmentList from './StudentAssessmentList';
import TakeAssessment from './TakeAssessment';

const StudentAssessmentPage = () => {
  const [selectedAssessment, setSelectedAssessment] = useState(null);

  const handleComplete = () => {
    alert("Assessment submitted!");
    setSelectedAssessment(null); // Return to list after submission
  };

  return (
    <div>
      {!selectedAssessment ? (
        <StudentAssessmentList onSelectAssessment={setSelectedAssessment} />
      ) : (
        <TakeAssessment
          assessment={selectedAssessment}
          onComplete={handleComplete}
        />
      )}
    </div>
  );
};

export default StudentAssessmentPage;
